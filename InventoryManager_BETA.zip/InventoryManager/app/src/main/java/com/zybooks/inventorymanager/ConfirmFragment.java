package com.zybooks.inventorymanager;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;


public class ConfirmFragment extends DialogFragment {

    public interface OnOptionSelectedListener {
        void onOptionClick(int which);
    }

    private OnOptionSelectedListener mListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle("Zero Inventory");
        builder.setMessage("Do you want to delete this item?");
        builder.setPositiveButton("Delete", (dialog, id) -> {
            mListener.onOptionClick(1);
        });
        builder.setNegativeButton("Keep at 0", (dialog, id) -> {
            mListener.onOptionClick(0);
        });

        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (OnOptionSelectedListener) context;
    }

}