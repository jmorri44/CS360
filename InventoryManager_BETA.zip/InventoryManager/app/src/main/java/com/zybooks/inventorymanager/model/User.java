package com.zybooks.inventorymanager.model;

import androidx.annotation.NonNull;

public class User {
    public User(@NonNull String userName, @NonNull String userPass){
        mUserName = userName;
        mUserPass = userPass;
    }

    private String mUserName;
    private String mUserPass;

    public String getUserName() {
        return mUserName;
    }

    public String getUserPass(){
        return mUserPass;
    }

    public void setUserName(String newName){
        mUserName = newName;
    }

    public void setUserPass(String newPass){
        mUserPass = newPass;
    }
}
