package com.zybooks.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.zybooks.inventorymanager.model.User;
import com.zybooks.inventorymanager.repo.UserRepository;

public class NewUserActivity extends AppCompatActivity {

    private EditText usernameText;
    private EditText passwordText;
    private Button createButton;
    private Button cancelButton;

    private String mUserName;
    private String mPassword;

    private UserRepository mUserRepo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        usernameText = findViewById(R.id.enter_username_text);
        passwordText = findViewById(R.id.new_pass_enter);

        findViewById(R.id.button_add_user).setOnClickListener(view -> onCreateClick());
        findViewById(R.id.button_cancel_add).setOnClickListener(view -> onCancelClick());

        mUserRepo = UserRepository.getInstance(this.getApplicationContext());


    }

    private void onCreateClick(){
        mUserName = usernameText.getText().toString();
        mPassword = passwordText.getText().toString();
        if (mUserName.length() == 0 || mPassword.length() == 0){
            Toast.makeText(this, "Please enter credentials", Toast.LENGTH_SHORT).show();
            return;
        }
        User user = new User(mUserName, mPassword);
        mUserRepo.addUser(user);
        setResult(RESULT_OK);
        finish();
        return;
    }

    private void onCancelClick(){
        setResult(RESULT_CANCELED);
        finish();
        return;
    }
}