package com.zybooks.inventorymanager;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.zybooks.inventorymanager.model.Item;
import com.zybooks.inventorymanager.viewmodel.ItemListViewModel;

import java.util.List;


public class ItemListActivity extends AppCompatActivity
        implements ItemDialogFragment.OnItemEnteredListener{

    private ItemAdapter mItemAdapter;
    private RecyclerView mRecyclerView;
    private ItemListViewModel mItemListViewModel;
    private SharedPreferences sharedPref;
    private final int REQUEST_SMS_PERMISSION_CODE = 0;

    private final String PHONE_NUMBER = "15555215554";


    private  List<Item> xItemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        mItemListViewModel = new ItemListViewModel(getApplication());

        findViewById(R.id.addButton).setOnClickListener(view -> testAdd());

        // Create 2 grid layout columns
        mRecyclerView = findViewById(R.id.item_list);
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        sharedPref = getSharedPreferences(
                "myprefs", Context.MODE_PRIVATE);

        // Show the items
       //updateUI(mItemListViewModel.getItems());
    }

    @Override
    protected void onResume(){
        super.onResume();
        updateUI(mItemListViewModel.getItems());
    }

    //MENU FUNCTIONS-----------------------------

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        // Determine which menu option was chosen
        if (item.getItemId() == R.id.menu_option_icon) {
            Intent intent = new Intent(this, options_activity.class);
            startActivity(intent);
            return true;
        }


        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //MEMBER FUNCTIONS--------------------------------------------------

    private void updateUI(List<Item> itemList) {
        mItemAdapter = new ItemAdapter(itemList);
        mRecyclerView.setAdapter(mItemAdapter);
    }

    private void testAdd(){
        // Start QuestionActivity with the selected subject
        Intent intent = new Intent(ItemListActivity.this, EditItemActivity.class);
        intent.putExtra(EditItemActivity.EXTRA_ITEM_NAME, "");
        intent.putExtra(EditItemActivity.EXTRA_ITEM_QUANTITY, 0);

        startActivity(intent);
    }



    public void onItemEntered(String itemText) {
        if (itemText.length() > 0) {
            Item item = new Item(itemText, 1);
            mItemListViewModel.addItem(item);
            updateUI(mItemListViewModel.getItems());
            notifyUser("changed", item);

            Toast.makeText(this, "Added " + itemText, Toast.LENGTH_SHORT).show();
        }
    }

    public void removeItem(String itemName){
        if(mItemListViewModel.removeItem(itemName)){
            notifyUser("zero", new Item(itemName, 0));
        };
        updateUI(mItemListViewModel.getItems());
    }
    //NOTIFICATIONS AND PERMISSIONS-------------------------------------------------

    public void notifyUser(String type, Item item){


        if (type.equals("zero")){
            if (sharedPref.getBoolean("NOTIFY_ALL", false)&&
                    sharedPref.getBoolean("NOTIFY_ZERO", false)){
                notifyZero(item);
            }
        }
        else if (type.equals("changed")){
            if (sharedPref.getBoolean("NOTIFY_ALL", false)&&
                    sharedPref.getBoolean("NOTIFY_CHANGE", false)){
                notifyChange(item);
            }
        }
    }


    private void notifyZero(Item item){
        if(PermissionsUtil.hasPermissions(this, Manifest.permission.SEND_SMS,
                R.string.sms_rational, REQUEST_SMS_PERMISSION_CODE)){
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(PHONE_NUMBER, null,
                    item.getName() + " has a balance of zero.", null, null);
            Toast.makeText(this, "Zero balance: " + item.getName(),Toast.LENGTH_SHORT);
        }

    }

    private void notifyChange(Item item){
        if(PermissionsUtil.hasPermissions(this, Manifest.permission.SEND_SMS,
                R.string.sms_rational, REQUEST_SMS_PERMISSION_CODE)){
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(PHONE_NUMBER, null,
                    item.getName() + " balance is now " + item.getCount(),
                    null, null);
            Toast.makeText(this, "Zero balance: " + item.getName(),Toast.LENGTH_SHORT);
        }

    }





//CLASSES----------------------------------------------------------------




    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Item> mItemList;

        public ItemAdapter(List<Item> items) {
            mItemList = items;
        }


        @Override
        public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position){
            holder.bind(mItemList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mItemList.size();
        }
    }

    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Item mItem;
        private final TextView mItemTextView;
        private final TextView mItemQuantityView;
        private final Button mDeleteButton;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list__inventory_item, parent, false));
            itemView.setOnClickListener(this::onClick);

            mItemTextView = itemView.findViewById(R.id.item_name);
            mItemQuantityView = itemView.findViewById(R.id.item_quantity_display);

            mDeleteButton = itemView.findViewById(R.id.button_delete);
            mDeleteButton.setOnClickListener(this::onDeleteClick);
        }

        public void bind(Item item, int position) {

            mItem = item;
            mItemTextView.setText(item.getName() + ": ");
            mItemQuantityView.setText(Integer.toString(item.getCount()));

        }

        public void onDeleteClick(View view){

            removeItem(mItem.getName());
        }

        @Override
        public void onClick(View view) {
            // Start QuestionActivity with the selected subject
            Intent intent = new Intent(ItemListActivity.this, EditItemActivity.class);
            intent.putExtra(EditItemActivity.EXTRA_ITEM_NAME, mItem.getName());
            intent.putExtra(EditItemActivity.EXTRA_ITEM_QUANTITY, mItem.getCount());

            startActivity(intent);
            //Toast.makeText(itemView.getContext(), "Clicked " + mItem.getName(), Toast.LENGTH_SHORT).show();
        }


    }
}