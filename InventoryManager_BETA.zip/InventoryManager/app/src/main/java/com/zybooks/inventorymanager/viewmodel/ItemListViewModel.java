package com.zybooks.inventorymanager.viewmodel;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventorymanager.R;
import com.zybooks.inventorymanager.model.Item;
import com.zybooks.inventorymanager.PermissionsUtil;
import java.util.List;

import com.zybooks.inventorymanager.model.Item;
import com.zybooks.inventorymanager.repo.InventoryRepository;

import java.util.List;

public class ItemListViewModel extends AppCompatActivity {

    private InventoryRepository inventoryRepo;


    private final int REQUEST_SMS_PERMISSION_CODE = 0;
    private final String PHONE_NUMBER = "15555215554";

    public ItemListViewModel(Application application){
       inventoryRepo = InventoryRepository.getInstance(application.getApplicationContext());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

    }

    public List<Item> getItems(){
        return inventoryRepo.getItems();
    }

    public void addItem(Item item){
        if(inventoryRepo.itemExists(item.getName())){
            Item newItem = new Item(item.getName(),
                    item.getCount()+ inventoryRepo.getItem(item.getName()).getCount() );
            editItem(newItem);
        }
        else{
            inventoryRepo.addItem(item);
        }

    }

    public Item getItem(String itemName){
        return inventoryRepo.getItem(itemName);
    }

    public boolean removeItem(String itemName){
        if (inventoryRepo.itemExists(itemName)){
            Item tempItem = inventoryRepo.getItem(itemName);
            inventoryRepo.removeItem(itemName);
            return true;
        }
        else{
            return false;
        }

    }

    public int editItem(Item item){
        if (inventoryRepo.itemExists(item.getName())){

            inventoryRepo.updateItem(item);

            return item.getCount();
        }
        else{
            return -1;
        }

    }

    //NOTIFICATIONS AND PERMISSIONS-------------------------------------------------






}