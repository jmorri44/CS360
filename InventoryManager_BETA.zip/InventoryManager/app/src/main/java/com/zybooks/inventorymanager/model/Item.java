package com.zybooks.inventorymanager.model;


import androidx.annotation.NonNull;

public class Item {

    public Item(@NonNull String itemName, @NonNull int itemCount){
        mName = itemName;
        mCount = itemCount;
    }

    private String mName;
    private int mCount;

    public String getName() {
        return mName;
    }

    public int getCount(){
        return mCount;
    }

    public void setName(String newName){
        mName = newName;
    }

    public void setCount(int newCount){
        mCount = newCount;
    }
}
