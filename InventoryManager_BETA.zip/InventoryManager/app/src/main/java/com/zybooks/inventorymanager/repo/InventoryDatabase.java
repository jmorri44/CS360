package com.zybooks.inventorymanager.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.zybooks.inventorymanager.model.Item;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int version = 1;

    public InventoryDatabase(Context context){
        super(context, DATABASE_NAME, null, version);

    }

    private static final class ItemTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_QUANTITY + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    //Adds an item to the database. Returns the _id number from the database.
    public long addItem(String newItem, int newQuantity) {

        if (itemExists(newItem)){
            return -1;
        }


        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.ItemTable.COL_NAME, newItem);
        values.put(InventoryDatabase.ItemTable.COL_QUANTITY, newQuantity);


        long itemId = db.insert(InventoryDatabase.ItemTable.TABLE, null, values);
        return itemId;
    }

    //Returns true if the specified item exists on the database, or false if not
    public boolean itemExists(String item) {
        SQLiteDatabase db = getReadableDatabase();
        boolean exists = false;

        String sql = "select * from " + InventoryDatabase.ItemTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { item });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String thisItem = cursor.getString(1);
                if (thisItem.equals(item)){
                    exists = true;
                    break;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return exists;
    }


    //Returns a count for the specified item. Returns 0 if the item does not exist.
    public int countItem(String item) {
        SQLiteDatabase db = getReadableDatabase();
        int myCount = 0;

        String sql = "select * from " + InventoryDatabase.ItemTable.TABLE + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { item });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String thisItem = cursor.getString(1);
                if (thisItem.equals(item)){
                    myCount = cursor.getInt(2);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return myCount;
    }

    //Updates an item itemName with a new count, if the item exists.
    // Returns a boolean value indicating whether an update was performed.
    public boolean updateItemCount(String itemName, int newCount) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_QUANTITY, newCount);

        int rowsUpdated = db.update(ItemTable.TABLE, values, "name = ?",
                new String[] { itemName });
        return rowsUpdated > 0;
    }

    //Deletes an item with the specified name.
    //Returns true if an item was deleted, or false otherwise.
    public boolean deleteItem(String itemName) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(ItemTable.TABLE, ItemTable.COL_NAME + " = ?",
                new String[] { itemName });
        return rowsDeleted > 0;
    }

    public List<Item> getItems(){
        SQLiteDatabase db = getReadableDatabase();
        int myCount = 0;
        List<Item> mItemList = new ArrayList<>();
        Item item;

        String sql = "select * from " + InventoryDatabase.ItemTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String thisItem = cursor.getString(1);

                myCount = cursor.getInt(2);
                item = new Item(thisItem, myCount);
                mItemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return mItemList;

    }


}








