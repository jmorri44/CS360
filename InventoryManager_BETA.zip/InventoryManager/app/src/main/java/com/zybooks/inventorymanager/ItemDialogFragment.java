package com.zybooks.inventorymanager;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class ItemDialogFragment extends DialogFragment {

    public interface OnItemEnteredListener {
        void onItemEntered(String subjectText);
    }

    private OnItemEnteredListener mListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final EditText itemEditText = new EditText(requireActivity());
        itemEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        itemEditText.setMaxLines(1);

        return new AlertDialog.Builder(requireActivity())
                .setTitle(R.string.item_fragment_title)
                .setView(itemEditText)
                .setPositiveButton(R.string.add_item, (dialog, whichButton) -> {
                    // Notify listener
                    String subject = itemEditText.getText().toString();
                    mListener.onItemEntered(subject.trim());
                })
                .setNegativeButton(R.string.cancel, null)
                .create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (OnItemEnteredListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


}
