package com.zybooks.inventorymanager;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventorymanager.repo.UserRepository;

public class LoginActivity extends AppCompatActivity {

    private EditText mUserName;
    private EditText mPassword;
    private UserRepository mUserRepo;

    private String userName;
    private String password;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.button_login).setOnClickListener(view -> onLoginClick());
        findViewById(R.id.button_create_account).setOnClickListener(view -> onCreateClick());

        mUserRepo = UserRepository.getInstance(this.getApplicationContext());

        mUserName = findViewById(R.id.username_text);
        mPassword = findViewById(R.id.password_text);



    }

    private void onLoginClick(){

        String userName = mUserName.getText().toString();
        String password = mPassword.getText().toString();

        if (userName.length() > 0 && password.length() > 0){
            if (mUserRepo.validateUser(userName, password)){
                Intent intent = new Intent(LoginActivity.this, ItemListActivity.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Login Denied", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(this, "Please enter credentials", Toast.LENGTH_SHORT).show();
        }



    }

    private void onCreateClick(){


        Intent intent = new Intent(LoginActivity.this, NewUserActivity.class);
        startActivity(intent);
    }


}
