package com.zybooks.inventorymanager.repo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int version = 1;

    public UserDatabase(Context context){
        super(context, DATABASE_NAME, null, version);

    }

    //Basic Table data unit
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    //Adds a user to the database. Returns true if successful, false if unsuccessful.
    public boolean addUser(String newUser, String newPass) {

        //Username already exists. Abort add.
        if (userExists(newUser)){
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, newUser);
        values.put(UserTable.COL_PASSWORD, newPass);


        long userId = db.insert(UserTable.TABLE, null, values);
        return true;
    }

    //Returns true if the specified user exists on the database, or false if not
    public boolean userExists(String user) {
        SQLiteDatabase db = getReadableDatabase();
        boolean exists = false;

        String sql = "select * from " + UserTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { user });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String thisUser = cursor.getString(1);
                if (thisUser.equals(user)){
                   exists = true;
                   break;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return exists;
    }

    //Takes a username and password argument, and validates against the database.
    //Returns true if the combination exists, or false if it does not.
    public boolean validateUser(String user, String pass) {
        SQLiteDatabase db = getReadableDatabase();
        boolean validated = false;

        String sql = "select * from " + UserTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { user });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String thisUser = cursor.getString(1);
                if (thisUser.equals(user)){
                    String thisPass = cursor.getString(2);
                    if (thisPass.equals(pass)){
                        validated = true;
                        break;
                    }
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return validated;
    }



}








