package com.zybooks.inventorymanager.repo;

import android.content.Context;

import com.zybooks.inventorymanager.model.User;

import java.util.ArrayList;
import java.util.List;

public class UserRepository {
    private static UserRepository mUserRepo;
    //private final List<User> mUserList;
    private UserDatabase myUserDB;


    public static UserRepository getInstance(Context context) {
        if (mUserRepo == null) {
            mUserRepo = new UserRepository(context);
        }
        return mUserRepo;
    }

    private UserRepository(Context context) {
        myUserDB = new UserDatabase(context);

        //mUserList = new ArrayList<>();

        addStarterData();
    }

    private void addStarterData() {
        // Add some users to begin
        myUserDB.addUser("Person1", "Pass1");


    }

    public boolean addUser(User user) {
        //mUserList.add(user);
        return myUserDB.addUser(user.getUserName(), user.getUserPass());

    }


    public boolean validateUser(String user, String pass){
        //for (User myUser: mUserList) {
          //  if (myUser.getUserName().equals(user)) {
            //    if (myUser.getUserPass().equals(pass)){
              //      return true;
                //}
            //}
        //}
        return myUserDB.validateUser(user, pass);

    }
}
