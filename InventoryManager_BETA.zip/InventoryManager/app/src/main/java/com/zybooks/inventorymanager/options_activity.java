package com.zybooks.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class options_activity extends AppCompatActivity {

    private Switch mySwitch;
    private CheckBox toggleZero;
    private CheckBox toggleChange;
    private TextView textZero;
    private TextView textChange;
    private final int REQUEST_SMS_PERMISSION_CODE = 0;

    private final String PHONE_NUMBER = "15555215554";


    private SharedPreferences sharedPref;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);


        //Settings for switch
        mySwitch = findViewById(R.id.notification_toggle_switch);
        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    changeNotifications(0, true);

                } else {
                    changeNotifications(0, false);
                }
            }
        });

        toggleZero = findViewById(R.id.zero_inventory_checkbox);
        toggleChange = findViewById(R.id.changed_inventory_checkbox);
        textZero = findViewById(R.id.zero_inventory_text);
        textChange = findViewById(R.id.changed_inventory_text);

        sharedPref = getSharedPreferences(
                "myprefs", Context.MODE_PRIVATE);

        //editor.putString("name", "Tamika");
        //editor.putInt("highScore", 500);
        //editor.apply();
        updateUI();
    }
    private void updateUI(){
        boolean notesOn = sharedPref.getBoolean("NOTIFY_ALL", false);
        boolean notesOnZero = sharedPref.getBoolean("NOTIFY_ZERO", false);
        boolean notesOnChange = sharedPref.getBoolean("NOTIFY_CHANGE", false);

        mySwitch.setChecked(notesOn);

        toggleChange.setChecked(notesOnChange);
        toggleZero.setChecked(notesOnZero);

        if (notesOn){
            toggleZero.setVisibility(View.VISIBLE);
            toggleChange.setVisibility(View.VISIBLE);
            textZero.setVisibility(View.VISIBLE);
            textChange.setVisibility(View.VISIBLE);
        }
        else{
            toggleZero.setVisibility(View.INVISIBLE);
            toggleChange.setVisibility(View.INVISIBLE);
            textZero.setVisibility(View.INVISIBLE);
            textChange.setVisibility(View.INVISIBLE);
        }

    }

    private void changeNotifications(int noteChange, boolean newValue){
        if (noteChange == 0){
            //Turn notifications on or off
            if(PermissionsUtil.hasPermissions(this, Manifest.permission.SEND_SMS,
                    R.string.sms_rational, REQUEST_SMS_PERMISSION_CODE)){

                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean("NOTIFY_ALL", newValue);
                editor.apply();
            }

            updateUI();


        }
        else if (noteChange == 1){
            //switch notifications for zero inventory
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putBoolean("NOTIFY_ZERO", newValue);
            editor.apply();

        }
        else if (noteChange == 2){
            //switch notifications for all changes
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putBoolean("NOTIFY_CHANGE", newValue);
            editor.apply();
        }
    }

    //PERMISSIONS UTILITIES
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_SMS_PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // Permission granted, update preferences
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean("NOTIFY_ALL", true);
                    editor.putBoolean("NOTIFY_ZERO", true);
                    editor.putBoolean("NOTIFY_CHANGE", true);
                    editor.apply();
                    updateUI();

                    //Send an SMS note
                    SmsManager sms = SmsManager.getDefault();
                    sms.sendTextMessage(PHONE_NUMBER, null,
                            "You have enabled message alerts for Inventory Manager",
                            null, null);

                }
                return;
            }
        }
    }



}







