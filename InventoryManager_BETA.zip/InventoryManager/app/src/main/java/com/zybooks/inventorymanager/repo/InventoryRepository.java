package com.zybooks.inventorymanager.repo;

import com.zybooks.inventorymanager.model.Item;


import android.content.Context;
import java.util.ArrayList;
import java.util.List;


public class InventoryRepository {

    private static InventoryRepository mInventoryRepo;
    //private final List<Item> mItemList;
    private final InventoryDatabase myDB;

    public static InventoryRepository getInstance(Context context) {
        if (mInventoryRepo == null) {
            mInventoryRepo = new InventoryRepository(context);
        }
        return mInventoryRepo;
    }

    private InventoryRepository(Context context) {
        myDB = new InventoryDatabase(context);

        //mItemList = new ArrayList<>();

        addStarterData();
    }

    private void addStarterData() {
        // Add a few items to work with
        myDB.addItem("Thing 1", 1);
        //addItem(item);


        myDB.addItem("Thing 2", 2);
        //addItem(item);

        myDB.addItem("Thing 3", 3);
        //addItem(item);

    }

    public boolean addItem(Item item) {
        if(itemExists(item.getName())){
            return false;
        }
        else{

            //mItemList.add(item);
            myDB.addItem(item.getName(), item.getCount());
            return true;
        }


    }

    public boolean removeItem(String itemName){
       // for (int i = 0; i < mItemList.size(); i++) {
         //   if (mItemList.get(i).getName().equals(itemName)) {
           //     mItemList.remove(i);
             //   return true;
            //}
        //}
        //return false;
        return myDB.deleteItem(itemName);
    }

    public boolean updateItem(Item item){
       // for (int i = 0; i < mItemList.size(); i++) {
         //   if (mItemList.get(i).getName().equals(item.getName())) {
           //     mItemList.set(i, item);
             //   return true;
            //}
        //}

        //return false;
        return myDB.updateItemCount(item.getName(), item.getCount());
    }

    public boolean itemExists(String itemName){
        //for (Item item: mItemList) {
          //  if (item.getName().equals(itemName)) {
            //    return true;
            //}
        //}

        //return false;
        return myDB.itemExists(itemName);
    }

    public Item getItem(String itemName) {
        //for (Item item: mItemList) {
          //  if (item.getName().equals(itemName)) {
            //    return item;
            //}
        //}

        //return null;
        int mycount = myDB.countItem(itemName);
        Item myitem = new Item(itemName, mycount);
        return myitem;
    }

    public List<Item> getItems() {
        //return mItemList;
        return myDB.getItems();
    }


}
