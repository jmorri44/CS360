package com.zybooks.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.zybooks.inventorymanager.model.Item;
import com.zybooks.inventorymanager.viewmodel.ItemListViewModel;

public class EditItemActivity extends AppCompatActivity
        implements ConfirmFragment.OnOptionSelectedListener{
    public static final String EXTRA_ITEM_NAME = "com.zybooks.inventorymanager.item_name";
    public static final String EXTRA_ITEM_QUANTITY = "com.zybooks.inventorymanager.item_quantity";

    private TextView mItemTitle;
    private TextView mOriginalCount;
    private TextView mOriginalCountText;
    private TextView mAddEditText;
    private EditText mNewCount;
    private EditText mNewName;

    private SharedPreferences sharedPref;
    private final int REQUEST_SMS_PERMISSION_CODE = 0;

    private final String PHONE_NUMBER = "15555215554";
    private boolean shouldDelete = false;

    private ItemListViewModel itemDB;

    private Item mItem;

    private String mItemName;
    private int mItemCount;

    private boolean addNewItem = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        sharedPref = getSharedPreferences(
                "myprefs", Context.MODE_PRIVATE);

        findViewById(R.id.button_commit).setOnClickListener(view -> saveButtonClick());
        findViewById(R.id.button_cancel).setOnClickListener(view -> cancelButtonClick());

        mAddEditText = findViewById(R.id.titleText);
        mItemTitle = findViewById(R.id.itemTitleText);
        mOriginalCount = findViewById(R.id.original_qty);
        mOriginalCountText = findViewById(R.id.original_qty_text);
        mNewCount = findViewById(R.id.new_quantity);
        mNewName = findViewById(R.id.new_name_text);

        Intent intent = getIntent();

        itemDB = new ItemListViewModel(this.getApplication());

        mItemName = intent.getStringExtra(EXTRA_ITEM_NAME);
        mItemCount = intent.getIntExtra(EXTRA_ITEM_QUANTITY, 0);

        if (mItemName.length() == 0) {

            addNewItem = true;

            mItem = new Item("BLANK_ITEM", 0);

            //Set up the UI
            mOriginalCountText.setText(R.string.text_new_name);
            mNewName.setVisibility(View.VISIBLE);
            mOriginalCount.setVisibility(View.GONE);
            mAddEditText.setText("Add Item");


        }
        else {

            mOriginalCountText.setText(R.string.text_original_quantity);
            mNewName.setVisibility(View.GONE);
            mOriginalCount.setVisibility(View.VISIBLE);
            mOriginalCount.setText(Integer.toString(mItemCount));
            mAddEditText.setText("Editing");

            mItemTitle.setText(mItemName);

            mItem = new Item(mItemName, mItemCount);


        }
    }

    //BUTTON CLICK METHODS------------------------------------------------------------

    @Override
    public void onOptionClick(int which) {


        if (which == 0){
            shouldDelete = false;
        }
        else {
            shouldDelete = true;
        }

        if (shouldDelete){
            itemDB.removeItem(mItemName);
            notifyUser("zero", new Item(mItemName, 0));

        }
        else{
            mItem.setName(mItemName);
            mItem.setCount(Integer.parseInt(mNewCount.getText().toString()));
            itemDB.editItem(mItem);
            notifyUser("changed", new Item(mItemName, 0));
        }
        setResult(RESULT_OK);
        finish();
        return;
    }


    private void saveButtonClick() {


        //Exits the function if the required fields are missing
        //Displays a toast message informing the user of the failure
        if (mNewCount.getText().toString().length() == 0){
            Toast.makeText(this, "Enter a quantity", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            if (addNewItem && mNewName.getText().toString().length() ==0){
                Toast.makeText(this, "Enter an item name", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        String getCount = mNewCount.getText().toString();
        if(Integer.parseInt(getCount) == 0){
            ConfirmFragment dialog = new ConfirmFragment();
            dialog.show(getSupportFragmentManager(), "confirmDialog");
            //calls onclick above
            return;


        }



        //Execute if adding new item
        if (addNewItem) {

            mItem.setCount(Integer.parseInt(getCount));
            mItem.setName(mNewName.getText().toString());
            itemDB.addItem(mItem);
        }
        //Execute if updating existing item
        else {
            mItem.setName(mItemName);
            mItem.setCount(Integer.parseInt(mNewCount.getText().toString()));
            itemDB.editItem(mItem);
        }


        // Send back OK result
        setResult(RESULT_OK);
        finish();
    }

    private void cancelButtonClick(){
        setResult(RESULT_CANCELED);
        finish();
    }

    //NOTIFICATIONS AND PERMISSIONS-------------------------------------------------



    public void notifyUser(String type, Item item){


        if (type.equals("zero")){
            if (sharedPref.getBoolean("NOTIFY_ALL", false)&&
                    sharedPref.getBoolean("NOTIFY_ZERO", false)){
                notifyZero(item);
            }
        }
        else if (type.equals("changed")){
            if (sharedPref.getBoolean("NOTIFY_ALL", false)&&
                    sharedPref.getBoolean("NOTIFY_CHANGE", false)){
                notifyChange(item);
            }
        }
    }


    private void notifyZero(Item item){
        if(PermissionsUtil.hasPermissions(this, android.Manifest.permission.SEND_SMS,
                R.string.sms_rational, REQUEST_SMS_PERMISSION_CODE)){
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(PHONE_NUMBER, null,
                    item.getName() + " has a balance of zero.", null, null);
            Toast.makeText(this, "Zero balance: " + item.getName(),Toast.LENGTH_SHORT);
        }

    }

    private void notifyChange(Item item){
        if(PermissionsUtil.hasPermissions(this, Manifest.permission.SEND_SMS,
                R.string.sms_rational, REQUEST_SMS_PERMISSION_CODE)){
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(PHONE_NUMBER, null,
                    item.getName() + " balance is now " + item.getCount(),
                    null, null);
            Toast.makeText(this, "Zero balance: " + item.getName(),Toast.LENGTH_SHORT);
        }

    }
}